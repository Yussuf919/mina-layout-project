purple
rgb(76, 31, 89)

white
rgb(255, 255, 255)

black
rgb(26, 26, 26)

grey
rgb(93, 87, 94)
